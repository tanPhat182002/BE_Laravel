<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\ProductServiceProvider::class,
    
];
